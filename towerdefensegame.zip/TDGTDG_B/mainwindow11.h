﻿#ifndef MAINWINDOW11_H
#define MAINWINDOW11_H

#include <QMainWindow>

#include <QList>
#include <bgmusic.h>
#include <QSound>
#include <QString>
namespace Ui {
class MainWindow11;
}
class WayPoint;
class Enemy;
class Bullet;
class CannonBullet;
class AudioPlayer;

class MainWindow11 : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow11(QWidget *parent = nullptr);
    ~MainWindow11();

    void getHpDamage(int damage = 1);
    void removedEnemy(Enemy *enemy);
    void removedBullet(Bullet *bullet);
    void addBullet(Bullet *bullet);
    void removedCannonBullet(CannonBullet *cannonbullet);
    void addCannonBullet(CannonBullet *cannonbullet);
    void awardGold(int gold);
    void contextMenuEvent(QContextMenuEvent *event);

    AudioPlayer* audioPlayer() const;
    QList<Enemy *> enemyList() const;
    QList<Enemy *> enemyList1() const;

public slots:
    void updateMap();
    void gameStart();
    void flagChange1();
    void flagChange2();

protected:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);

private:
    Ui::MainWindow11 *ui;

    void loadTowerPositions();
    void addWayPoints();
    bool loadWave();
    bool canBuyTower() const;
    void drawWave(QPainter *painter);
    void drawHP(QPainter *painter);
    void drawXT(QPainter *painter);
    void drawPlayerGold(QPainter *painter);
    void doGameOver();
    void preLoadWavesInfo();
    void act();
    void removeDeath();



    //数据成员
    int m_waves;
    int m_playerHp;
    int m_playrGold;
    bool m_gameEnded;
    bool m_gameWin;

    AudioPlayer *m_audioPlayer;
    QList<QVariant> m_wavesInfo;

    QList<WayPoint *> m_wayPointsList;
    QList<WayPoint *> m_wayPointsList1;

    QList<Enemy *> m_enemyList;
    QList<Enemy *> m_enemyList1;
    QList<Bullet *> m_bulletList;
    QList<CannonBullet *> m_cannonbulletList;
    BgMusic attackedcastle_music;
    BgMusic collectpotion_music ;
    BgMusic enemydie_music ;
    BgMusic neverend_music;
    BgMusic settower_music ;
    BgMusic win_music;
};

#endif // MAINWINDOW11_H
